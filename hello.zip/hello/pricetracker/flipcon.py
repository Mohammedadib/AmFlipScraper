from selenium import webdriver
import time

DIRECTORY = 'reports'
NAME = 'oppo'
CURRENCY = '₹'

MIN_PRICE = '25000'
MAX_PRICE = '100000'

FILTERS = {
    'min' : MIN_PRICE,
    'max' : MAX_PRICE
}
BASE_URL1 = "https://www.flipkart.com"

# PATH = "C:\Program Files (x86)\chromedriver_win32 (1)\chromedriver.exe"



# driver.get(BASE_URL)

# time.sleep(3)

# search = driver.find_element_by_name("field-keywords")
# search.send_keys(NAME)

# time.sleep(2)
# search.send_keys(Keys.ENTER)

# def get_chrome(options):
#     return webdriver.Chrome(PATH, )

def get_chrome_web_driver(options):
    return webdriver.Chrome(r"C:\chromedriver\chromedriver.exe", chrome_options=options)


def get_web_driver_options():
    return webdriver.ChromeOptions()


def set_ignore_certificate_error(options):
    options.add_argument('--ignore-certificate-errors')


def set_automation_as_head_less(options):
    options.add_argument('--headless')