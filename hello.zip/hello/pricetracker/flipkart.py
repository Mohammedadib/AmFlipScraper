from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import NoSuchElementException
from datetime import datetime
import re
import time
import json
from .flipcon import (
    NAME,
    BASE_URL1,
    CURRENCY,
    DIRECTORY,
    get_chrome_web_driver,
    get_web_driver_options,
    set_ignore_certificate_error,
    # set_automation_as_head_less,

)


class GenerateReport:
    def __init__(self, file_name, base_link , currency, data):
        self.data = data
        self.file_name = file_name
        # self.filters = filters
        self.base_link = base_link
        self.currency = currency
        report = {
            'title': self.file_name,
            'date' : self.get_now(),
            'best_item': self.get_best_item(),
            'currency': self.currency,
            # 'filters': self.filters,
            'base_link': self.base_link,
            'products': self.data
        }
        print("Creating report...")
        with open(f'{DIRECTORY}/{file_name}.json', 'w') as f:
            json.dump(report, f)
        print("Done...")


    def get_now(self):
        now = datetime.now()
        return now.strftime("%d/%m/%y %H:%M:%S")


    def get_best_item(self):
        try:
            return sorted(self.data, key=lambda k : k['price'])[0]
        except Exception as e:
            print(e)
            print("problems with sorting items")
            return None


class FlipkartAPI:
    def __init__(self, search_term, base_url, currency):
        self.search_term = search_term
        self.base_url = base_url
        self.currency = currency
        options = get_web_driver_options()
        set_ignore_certificate_error(options)
        # set_automation_as_head_less(options)
        # set_browser_as_incognito(options)
        self.driver = get_chrome_web_driver(options)
        # self.price_filter = f"&rh=p_36%3A{filters['min']}00-{filters['max']}00"
        
        
    def run(self):
        print("Starting Script...")
        print(f"Looking for {self.search_term} products..")
        links = self.get_products_links()
        time.sleep(2)
        if not links:
            print("Script has been stopped")
            return
        print(f" Got {len(links)} links of product")
        # print(links)
        print(" Getting info about products..")
        products = self.get_products_info(links)
        print(f"Got info about {len(products)} products..")
        self.driver.quit()
        return products


    def get_products_links(self):
        self.driver.get(self.base_url)
        element = self.driver.find_element_by_xpath('//*[@id="container"]/div/div[1]/div[1]/div[2]/div[2]/form/div/div/input')
        element.send_keys(self.search_term)
        element.send_keys(Keys.ENTER)
        time.sleep(3)  # wait to load page
        self.driver.get(f'{self.driver.current_url}')
        print(f"Our url: {self.driver.current_url}")
        time.sleep(3)  # wait to load page
        result_list = self.driver.find_elements_by_xpath('//*[@id="container"]/div/div[3]/div[2]/div/div[2]')
            # '//*[@id="container"]/div/div[3]/div[2]/div/div[2]')
               
              
               
        links = []
        try:
            results = result_list[0].find_elements_by_class_name(
                '_1fQZEK') #'s1Q9rs'
            links = [link.get_attribute('href') for link in results]
            return links
        except Exception as e:
            print("Didn't get any products...")
            print(e)
            return links


    def get_products_info(self, links):
        pids = self.get_pids(links)
        products = []
        for pid in pids[:2]:
            product = self.get_single_product_info(pid)
            if product:
                products.append(product)
        return products


    def get_pids(self, links):
        return [self.get_pid(link) for link in links]


    def get_single_product_info(self, pid):
        print(f"Product ID: {pid} - getting data...")
        product_short_url = self.shorten_url(pid)
        self.driver.get(f'{product_short_url}')
        time.sleep(2)
        title = self.get_title()
        seller = self.get_seller()
        price = self.get_price()
        if title and seller and price:
            product_info = {
                'pid': pid,
                'url': product_short_url,
                'title': title,
                'seller': seller,
                'price': price
            }
            return product_info
        return None


    def get_title(self):
        try:
            return self.driver.find_element_by_class_name('B_NuCI').text 
        except Exception as e:
            print(e)
            print(f"Can't get title of a product - {self.driver.current_url}")
            return None

    def get_seller(self):
        try:
            return self.driver.find_element_by_id('sellerName').text
        except Exception as e:
            print(e)
            print(f"Can't get seller of a product - {self.driver.current_url}")
            return None

    def get_price(self):
        price = None
        try:
            price = self.driver.find_element_by_class_name('_25b18c').text
            print(price)
            price = self.convert_price(price)
        # except NoSuchElementException:
        #     try:
        #         availability = self.driver.find_element_by_id('_1mzTZn').text
        #         if '_1mzTZn' in availability:
        #             price = self.driver.find_element_by_class_name('_1vC4OE _3qQ9m1').text
        #             price = price[price.find(self.currency):]
        #             price = self.convert_price(price)
        #     except Exception as e:
        #         print(e)
        #         print(f"Can't get price of a product - {self.driver.current_url}")
        #         return None
        except Exception as e:
            print(e)
            print(f"Can't get price of a product - {self.driver.current_url}")
            return None
        return price


    def get_pid(self, product_link):
        return product_link[product_link.find('com/') + 4:product_link.find('&lid')]

    def shorten_url(self, pid):
        return self.base_url + '/' + pid
        

    def convert_price(self, price):
        # price = float(re.sub(r"[^\d.]", "", price))
        # price = float(flipkartprice.strip()[1:].replace(',', ''))
        # converted_price = float(re.sub(r"[^\d.]", "", price))
        # price = float(price[1:].replace(",", ""))
        # con = float(price[:'\u20b9'])
        price = price.split("₹")[1]
        print(price)
        # con = price
        return price

        

if __name__ == "__main__":
    on = FlipkartAPI(NAME, BASE_URL1, CURRENCY)
    data = on.run()
    GenerateReport(NAME, BASE_URL1, CURRENCY, data)