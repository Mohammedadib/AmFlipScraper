from django.contrib import admin
from django.urls import path
from home import views

urlpatterns = [
    
    path('', views.index, name='home'),
    path('amazon.html', views.amazon, name='amazon'),
    path('amazon', views.amazon, name='amazon'),
    path('flipkart.html', views.flipkart, name='flipkart'),
    path('flipkart', views.flipkart, name='flipkart'),
    path('findAmazon', views.findAmazon,),
    path('searchFlipkart', views.searchFlipkart,),
    
  
]