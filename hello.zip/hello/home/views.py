from django.shortcuts import render, HttpResponse
from django.core.exceptions import *

import reports
from pricetracker.amazon import GenerateReport
from pricetracker.amazon import AmazonAPI
from pricetracker.config import (
    NAME,
    BASE_URL,
    CURRENCY,
    DIRECTORY,
    # get_chrome_web_driver,
    # get_web_driver_options,
    # set_automation_as_head_less,
    # set_ignore_certificate_error,
    FILTERS,

)
from selenium.webdriver.common.keys import Keys
from selenium.common.exceptions import NoSuchElementException
import time
from datetime import datetime
import json
import re 

from pricetracker.flipkart import GenerateReport
from pricetracker.flipkart import FlipkartAPI


from pricetracker.flipcon import (
    NAME,
    BASE_URL1,
    CURRENCY,
    DIRECTORY,
    # get_chrome_web_driver,
    # get_web_driver_options,
    # set_ignore_certificate_error,
    # set_automation_as_head_less,

)
# Create your views here.
def index(request):
    return render(request,'index.html')

def amazon(request):
    return render(request,'amazon.html')

def flipkart(request):
    return render(request,'flipkart.html')


def findAmazon(request):
    if request.method == 'POST':
        textfield = request.POST['textfield']
        print(textfield)
        NAME = textfield
        am =  AmazonAPI(NAME, BASE_URL, CURRENCY, FILTERS)
        data = am.run()
        GenerateReport(NAME, BASE_URL, CURRENCY, data)
        print("gathering Json data....")
        data1 = None
        # json_ = NAME +".json"
        
        with open(f'{DIRECTORY}/{NAME}.json') as json_file:
            data1 = json.load(json_file)

            # for item in data1['best_items']:
            #     print(item['asin','url','tilte','seller','price'])
        return render(request,'output.html', data1)

    else:
        return render(request, 'amazon.html')



def searchFlipkart(request):
    if request.method == 'POST':
        textfield1 = request.POST['textname']
        print(textfield1)
        NAME = textfield1
        on = FlipkartAPI(NAME, BASE_URL1, CURRENCY)
        data = on.run()
        GenerateReport(NAME, BASE_URL1, CURRENCY, data)
        print("gathering Json data....")
        data1 = None
        # json_ = NAME +".json"
        
        with open(f'{DIRECTORY}/{NAME}.json') as json_file:
            
            data1 = json.load(json_file)
        return render(request,'output.html',data1)

        # return render(request,'output.html')
    else:
        return render(request, 'flipkart.html')




